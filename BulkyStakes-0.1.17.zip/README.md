# Bulky Stakes

A standalone Steamodded difficulty expansion that adds the Bulky Joker sticker,
Australium Stake, and Joker Stake.

Author: **S1XLV**

## Difficulty levels

- **Australium Stake** follows Gold Stake and gives compatible Jokers an
  independent 30% chance to receive the Bulky sticker.
- **Joker Stake** follows Australium Stake and uses the Ante base-score curve
  `100, 300, 1100, 3900, 12000, 37000, 100000, 200000, 400000`. Ante 9 and later
  continue from 400,000 with the base game's endless exponential formula.

## Bulky rules

- Purchase cost is doubled; sell value remains at the Joker's original value.
- A Bulky Joker occupies two Joker slots and doubles its supported effects.
- Calculated Chips and Mult effects trigger twice. XMult is doubled linearly;
  for example, `X3` becomes `X6`, not `X9`.
- End-of-round cash rewards are doubled, including Delayed Gratification.
- Rental charges twice and Perishable loses two rounds per end of round.
- Supported static passives receive a second copy of their effect.
- Bulky and Negative are mutually exclusive; Negative takes priority.
- Jokers created by Riff-raff, Judgement, Wraith, or The Soul are stickerless.
- Ankh and Invisible Joker copies retain stickers. If a Bulky copy exceeds the
  slot limit, an eligible non-Eternal Joker is Squeezed; otherwise another valid
  copy target is selected.
- Retrigger Jokers, explicitly incompatible Jokers, and vanilla Legendary
  Jokers cannot receive Bulky. Per-card XMult Jokers remain eligible.

## Sticker positions

- Without Eternal or Perishable: the normal Eternal/Perishable position.
- With Eternal or Perishable but without Rental: the normal Rental position.
- With Eternal or Perishable and Rental: one sticker interval below Rental.

## Requirements

- Balatro for Steam
- Lovely
- Steamodded `1.0.0~`

## Installation

Extract the mod into its own folder under `%AppData%\Balatro\Mods`. The manifest
must be located at:

`%AppData%\Balatro\Mods\BulkyStakes\bulky_stakes.json`

Remove older copies of the same mod before installing version `0.1.17`.

## Compatibility

Balatro Balance Patch is optional. When both mods are enabled, Australium Stake
and Joker Stake inherit the balance mod's Blue, Orange, and Gold Stake changes.

## Localization

Includes all 15 locales registered by the base game: English, German, both
Spanish variants, French, Indonesian, Italian, Japanese, Korean, Dutch, Polish,
Brazilian Portuguese, Russian, Simplified Chinese, and Traditional Chinese.
