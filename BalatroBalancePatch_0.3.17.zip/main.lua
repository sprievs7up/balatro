-- Shared helpers

local function take_joker(key, definition)
    local owned = SMODS.Joker:take_ownership(key, definition, true)
    assert(owned, ('[Balatro Balance Patch] Could not take ownership of j_%s'):format(key))
    return owned
end

local function take_voucher(key, definition)
    local owned = SMODS.Voucher:take_ownership(key, definition, true)
    assert(owned, ('[Balatro Balance Patch] Could not take ownership of v_%s'):format(key))
    return owned
end

local function gold_interest_is_active()
    return G
        and G.GAME
        and G.GAME.modifiers
        and G.GAME.modifiers.bbp_gold_interest == true
end

-- Mirrors vanilla Flower Pot suit assignment. Natural cards are counted first;
-- Wild Cards then fill one still-missing suit apiece.
local function count_flower_pot_suits(scoring_hand)
    local suits = {
        Hearts = 0,
        Diamonds = 0,
        Spades = 0,
        Clubs = 0,
    }

    for _, playing_card in ipairs(scoring_hand or {}) do
        if not SMODS.has_any_suit(playing_card) then
            if playing_card:is_suit('Hearts', true) and suits.Hearts == 0 then
                suits.Hearts = 1
            elseif playing_card:is_suit('Diamonds', true) and suits.Diamonds == 0 then
                suits.Diamonds = 1
            elseif playing_card:is_suit('Spades', true) and suits.Spades == 0 then
                suits.Spades = 1
            elseif playing_card:is_suit('Clubs', true) and suits.Clubs == 0 then
                suits.Clubs = 1
            end
        end
    end

    for _, playing_card in ipairs(scoring_hand or {}) do
        if SMODS.has_any_suit(playing_card) then
            if playing_card:is_suit('Hearts') and suits.Hearts == 0 then
                suits.Hearts = 1
            elseif playing_card:is_suit('Diamonds') and suits.Diamonds == 0 then
                suits.Diamonds = 1
            elseif playing_card:is_suit('Spades') and suits.Spades == 0 then
                suits.Spades = 1
            elseif playing_card:is_suit('Clubs') and suits.Clubs == 0 then
                suits.Clubs = 1
            end
        end
    end

    return suits.Hearts + suits.Diamonds + suits.Spades + suits.Clubs
end

local function reserve_consumable_slots(amount)
    G.GAME.consumeable_buffer = (G.GAME.consumeable_buffer or 0) + amount
end

local function release_consumable_slots(amount)
    G.GAME.consumeable_buffer = math.max(0, (G.GAME.consumeable_buffer or 0) - amount)
end

local function available_consumable_slots()
    return G.consumeables.config.card_limit
        - (#G.consumeables.cards + (G.GAME.consumeable_buffer or 0))
end

local function last_tarot_or_planet_key()
    local key = G.GAME.last_tarot_planet
    local center = key and G.P_CENTERS[key]
    if center and (center.set == 'Tarot' or center.set == 'Planet') then
        return key
    end
    return 'c_fool'
end

local function current_blackboard_suit()
    return G
        and G.GAME
        and G.GAME.current_round
        and G.GAME.current_round.bbp_blackboard_suit
        or 'Spades'
end

local function has_base_suit(card, suit)
    return card
        and card.base
        and card.base.suit == suit
end

local function matches_blackboard_suit(card, suit)
    if not card or not card.ability or card.ability.effect == 'Stone Card' then
        return false
    end

    -- Wild Cards keep their vanilla ability to satisfy any suit. Use the
    -- printed suit otherwise so Smeared Joker cannot merge the two targets.
    if card.ability.name == 'Wild Card' and not card.debuff then
        return true
    end

    return has_base_suit(card, suit)
end

local function next_blackboard_suit()
    local has_spades = false
    local has_clubs = false

    for _, playing_card in ipairs(G.playing_cards or {}) do
        has_spades = has_spades or has_base_suit(playing_card, 'Spades')
        has_clubs = has_clubs or has_base_suit(playing_card, 'Clubs')
        if has_spades and has_clubs then break end
    end

    if has_spades ~= has_clubs then
        return has_spades and 'Spades' or 'Clubs'
    end

    local previous = G.GAME.current_round.bbp_blackboard_suit
    return previous == 'Spades' and 'Clubs' or 'Spades'
end

-- Blackboard locks to the only black suit in the full deck. If both black
-- suits or neither black suit are present, its target alternates each round.
SMODS.current_mod.reset_game_globals = function()
    if not G or not G.GAME or not G.GAME.current_round then return end

    G.GAME.current_round.bbp_blackboard_suit = next_blackboard_suit()
end

-- Joker balance overrides

-- Greedy, Lusty, Wrathful, and Gluttonous Joker
for _, data in ipairs({
    { key = 'greedy_joker', suit = 'Diamonds' },
    { key = 'lusty_joker', suit = 'Hearts' },
    { key = 'wrathful_joker', suit = 'Spades' },
    -- The vanilla internal key intentionally contains this spelling.
    { key = 'gluttenous_joker', suit = 'Clubs' },
}) do
    take_joker(data.key, {
        config = { extra = { s_mult = 4, suit = data.suit } },
    })
end

-- Banner
take_joker('banner', {
    config = { extra = 40 },
})

-- Mystic Summit
take_joker('mystic_summit', {
    config = { extra = { chips = 150, d_remaining = 0 } },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.chips, card.ability.extra.d_remaining } }
    end,
    calculate = function(self, card, context)
        if context.joker_main
            and G.GAME.current_round.discards_left == card.ability.extra.d_remaining then
            return { chips = card.ability.extra.chips }
        end
    end,
})

-- 8 Ball
take_joker('8_ball', {
    config = { extra = { odds = 4, copies = 1 } },
    loc_vars = function(self, info_queue, card)
        local numerator, denominator = SMODS.get_probability_vars(
            card,
            1,
            card.ability.extra.odds,
            'bbp_8_ball'
        )
        return { vars = { numerator, denominator, card.ability.extra.copies } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            if context.other_card:get_id() == 8
                and available_consumable_slots() >= card.ability.extra.copies
                and SMODS.pseudorandom_probability(
                    card,
                    'bbp_8_ball',
                    1,
                    card.ability.extra.odds,
                    'bbp_8_ball'
                ) then
                local copies = card.ability.extra.copies
                reserve_consumable_slots(copies)
                return {
                    extra = {
                        focus = card,
                        message = localize('k_bbp_one_fool'),
                        func = function()
                            G.E_MANAGER:add_event(Event({
                                trigger = 'before',
                                delay = 0,
                                func = function()
                                    for index = 1, copies do
                                        SMODS.add_card({
                                            key = 'c_fool',
                                            area = G.consumeables,
                                            no_edition = true,
                                            key_append = 'bbp_8_ball_' .. index,
                                        })
                                    end
                                    release_consumable_slots(copies)
                                    return true
                                end,
                            }))
                        end,
                    },
                    colour = G.C.SECONDARY_SET.Tarot,
                }
            end

            -- Returning a truthy second value prevents Card:calculate_joker from
            -- falling through to vanilla 8 Ball, whose numeric extra is replaced
            -- by this mod's { odds, copies } table.
            return nil, true
        end
    end,
})

-- Scary Face
take_joker('scary_face', {
    config = { extra = 40 },
})

-- Scholar
take_joker('scholar', {
    rarity = 1,
    config = { extra = { mult = 5, chips = 20 } },
})

-- Blackboard
take_joker('blackboard', {
    config = { extra = 3 },
    loc_vars = function(self, info_queue, card)
        local suit = current_blackboard_suit()
        local extra = card and card.ability and card.ability.extra or self.config.extra
        return {
            vars = {
                extra,
                localize(suit, 'suits_plural'),
                colours = { G.C.SUITS[suit] },
            },
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local suit = current_blackboard_suit()
            local all_match = true

            for _, held_card in ipairs(G.hand.cards) do
                if not matches_blackboard_suit(held_card, suit) then
                    all_match = false
                    break
                end
            end

            -- An empty hand intentionally satisfies the condition, as in vanilla.
            if all_match then
                return { x_mult = card.ability.extra }
            end
        end
    end,
})

-- Hologram
take_joker('hologram', {
    config = { extra = 0.2, Xmult = 1 },
})

-- Arrowhead
take_joker('arrowhead', {
    config = { extra = 40 },
})

-- Green Joker
take_joker('green_joker', {
    config = { extra = { hand_add = 1, discard_sub = 2 }, mult = 4 },
})

-- Gros Michel
take_joker('gros_michel', {
    config = { extra = { odds = 10, mult = 15 } },
})

-- Seance
take_joker('seance', {
    config = { extra = { poker_hand = 'Straight Flush' } },
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue + 1] = G.P_CENTERS.e_negative
        local poker_hand = card
            and card.ability
            and card.ability.extra
            and card.ability.extra.poker_hand
            or self.config.extra.poker_hand
        return {
            vars = {
                localize(poker_hand, 'poker_hands'),
            },
        }
    end,
    calculate = function(self, card, context)
        if context.joker_main
            and next(context.poker_hands[card.ability.extra.poker_hand]) then
            G.E_MANAGER:add_event(Event({
                trigger = 'before',
                delay = 0,
                func = function()
                    SMODS.add_card({
                        set = 'Spectral',
                        area = G.consumeables,
                        edition = 'e_negative',
                        key_append = 'bbp_seance',
                    })
                    return true
                end,
            }))
            return {
                message = localize('k_plus_spectral'),
                colour = G.C.SECONDARY_SET.Spectral,
            }
        end
    end,
})

-- Erosion
take_joker('erosion', {
    config = { extra = 5 },
})

-- Hiker
take_joker('hiker', {
    cost = 7,
    config = { extra = 1 },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
            context.other_card.ability.perma_mult = context.other_card.ability.perma_mult
                + card.ability.extra
            return {
                message = localize('k_upgrade_ex'),
                colour = G.C.MULT,
            }
        end
    end,
})

-- Loyalty Card
take_joker('loyalty_card', {
    rarity = 1,
})

-- Superposition
take_joker('superposition', {
    config = {},
    rarity = 3,
    cost = 10,
    calculate = function(self, card, context)
        if context.joker_main then
            local has_ace = false
            for _, playing_card in ipairs(context.scoring_hand or {}) do
                if playing_card:get_id() == 14 then
                    has_ace = true
                    break
                end
            end

            if has_ace and next(context.poker_hands['Straight']) then
                local consumable_key = last_tarot_or_planet_key()
                G.E_MANAGER:add_event(Event({
                    trigger = 'before',
                    delay = 0,
                    func = function()
                        SMODS.add_card({
                            key = consumable_key,
                            area = G.consumeables,
                            edition = 'e_negative',
                            key_append = 'bbp_superposition_negative',
                        })
                        return true
                    end,
                }))
                return {
                    message = localize('k_bbp_negative_only'),
                    colour = G.C.SECONDARY_SET.Tarot,
                }
            end
        end
    end,
})

-- Red Card
take_joker('red_card', {
    config = { extra = 4, mult = 0 },
})

-- Square Joker
take_joker('square', {
    config = { extra = { chips = 16, chip_mod = 4 } },
})

-- Stone Joker
take_joker('stone', {
    config = { extra = 50 },
})

-- Throwback
take_joker('throwback', {
    config = { extra = 0.5 },
})

-- Flower Pot
take_joker('flower_pot', {
    rarity = 2,
    cost = 6,
    config = { extra = { two = 1.25, three = 2, four = 3 } },
    loc_vars = function(self, info_queue, card)
        local extra = card.ability.extra
        return { vars = { extra.two, extra.three, extra.four } }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local suit_count = count_flower_pot_suits(context.scoring_hand)
            local extra = card.ability.extra
            local x_mult = suit_count == 4 and extra.four
                or suit_count == 3 and extra.three
                or suit_count == 2 and extra.two

            if x_mult then
                return { x_mult = x_mult }
            end
        end
    end,
})

-- Hit the Road
take_joker('hit_the_road', {
    config = { extra = 0.75 },
})

-- The Family
take_joker('family', {
    config = { Xmult = 5, type = 'Four of a Kind' },
})

-- The Tribe
take_joker('tribe', {
    config = { Xmult = 2.5, type = 'Flush' },
})

-- Satellite
take_joker('satellite', {
    config = { extra = 2 },
})

-- Bootstraps
take_joker('bootstraps', {
    config = { extra = { mult = 4, dollars = 5 } },
})

-- Golden Ticket
take_joker('ticket', {
    config = { extra = 5 },
})

-- Stake and interest overrides

-- To the Moon uses the Gold Stake interest basis when it is active.
take_joker('to_the_moon', {
    config = { extra = 1 },
    loc_vars = function(self, info_queue, card)
        local extra = card and card.ability and card.ability.extra or self.config.extra
        local interest_scale = gold_interest_is_active() and 2 or 1
        local interest_basis = gold_interest_is_active() and 10 or 5
        return { vars = { extra * interest_scale, interest_basis } }
    end,
})

-- Gold Stake uses a lower interest balance cap, so its interest vouchers use
-- Gold-specific caps. On all lower Stakes these remain at their vanilla values.
take_voucher('seed_money', {
    config = { extra = 50 },
    loc_vars = function()
        return { vars = { gold_interest_is_active() and 8 or 10 } }
    end,
    redeem = function()
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.interest_cap = gold_interest_is_active() and 40 or 50
                return true
            end,
        }))
    end,
})

take_voucher('money_tree', {
    config = { extra = 100 },
    loc_vars = function()
        return { vars = { gold_interest_is_active() and 16 or 20 } }
    end,
    redeem = function()
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.interest_cap = gold_interest_is_active() and 80 or 100
                return true
            end,
        }))
    end,
})

-- Blue Stake enables Perishable Jokers without the vanilla discard penalty.
local blue_stake = SMODS.Stake:take_ownership('blue', {
    modifiers = function()
        G.GAME.modifiers.enable_perishables_in_shop = true
    end,
}, true)
assert(blue_stake, '[Balatro Balance Patch] Could not take ownership of stake_blue')

-- Orange Stake enables Rental Jokers; Perishable is inherited from Blue.
local orange_stake = SMODS.Stake:take_ownership('orange', {
    modifiers = function()
        G.GAME.modifiers.enable_rentals_in_shop = true
    end,
}, true)
assert(orange_stake, '[Balatro Balance Patch] Could not take ownership of stake_orange')

-- Gold Stake uses $2 interest per $10, capped at $4 before vouchers.
local gold_stake = SMODS.Stake:take_ownership('gold', {
    modifiers = function()
        G.GAME.modifiers.bbp_gold_interest = true
        G.GAME.modifiers.bbp_interest_basis = 10
        G.GAME.modifiers.bbp_interest_scale = 2
        G.GAME.interest_cap = 20
    end,
}, true)
assert(gold_stake, '[Balatro Balance Patch] Could not take ownership of stake_gold')
