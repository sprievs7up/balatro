# Balatro Balance Patch

A Steamodded balance mod for vanilla Jokers and Stakes. It changes existing
game objects and does not add new cards.

Author: **S1XLV**

## Joker changes

- Greedy, Lusty, Wrathful, and Gluttonous Joker: `+4 Mult` for their suit.
- Banner: `+40 Chips` per remaining discard.
- Mystic Summit: `+150 Chips` at zero remaining discards.
- 8 Ball: each scoring 8 has a 1 in 4 chance to create one The Fool when a
  consumable slot is available.
- Scary Face: `+40 Chips` per scoring face card.
- Scholar: Common; scoring Aces give `+20 Chips` and `+5 Mult`.
- Blackboard: gives `X3 Mult` only when every card held in hand matches its
  target black suit. If the full deck contains only Spades or only Clubs, that
  suit is selected; if both or neither are present, the target alternates each
  round. An empty hand still satisfies the condition.
- Hologram: gains `X0.2 Mult` whenever a playing card is added to the deck.
- Arrowhead: scoring Spade cards give `+40 Chips`.
- Green Joker: starts at `+4 Mult`, gains `+1 Mult` per hand played, and loses
  `2 Mult` per discard without falling below zero.
- Gros Michel: its end-of-round destruction chance is reduced to 1 in 10.
- Seance: a Straight Flush creates a random Negative Spectral card, including
  when the consumable area is full.
- Erosion: gains `+5 Mult` for each card below the deck's starting size.
- Hiker: costs `$7`; scoring cards permanently gain `+1 Mult`.
- Loyalty Card: Common.
- Superposition: Rare, costs `$10`, and creates a Negative copy of the last
  Tarot or Planet used when a played Straight contains an Ace. It falls back
  to a Negative The Fool when no prior card is available.
- Red Card: gains `+4 Mult` per skipped Booster Pack.
- Square Joker: starts at `+16 Chips` and retains its `+4 Chips` growth.
- Stone Joker: `+50 Chips` per Stone Card in the full deck.
- Throwback: `X0.5 Mult` per skipped Blind.
- Flower Pot: Uncommon, costs `$6`, and gives `X1.25`, `X2`, or `X3 Mult`
  when scoring cards represent two, three, or four suits.
- Hit the Road: gains `X0.75 Mult` per Jack discarded that round.
- The Family: `X5 Mult` on Four of a Kind hands.
- The Tribe: `X2.5 Mult` on Flush hands.
- Satellite: `$2` per unique Planet used during the run.
- Bootstraps: `+4 Mult` per `$5` held.
- Golden Ticket: scoring Gold Cards earn `$5`.
- To the Moon: on Gold Stake, gives `$2` of additional interest per `$10`.

## Stake changes

- Blue Stake enables Perishable Jokers and no longer removes a discard.
- Purple Stake retains its vanilla scoring requirement increase.
- Orange Stake enables Rental Jokers.
- Gold Stake gives `$2` interest per `$10`, with a base maximum of `$4`.
- Seed Money and Money Tree raise the Gold Stake interest thresholds to `$40`
  and `$80`, allowing maximum interest of `$8` and `$16`.

## Voucher changes

- Magic Trick makes every playing card generated for the shop Enhanced. The
  pool contains Bonus, Mult, Wild, Glass, Steel, Stone, Gold, and Lucky Cards.
- Illusion makes each shop playing card receive Edition only, Seal only, or
  both, with each result equally likely. Editions retain the vanilla split of
  50% Foil, 35% Holographic, and 15% Polychrome; Seals are chosen uniformly.
- Voucher artwork is unchanged in this release.

## Requirements

- Balatro for Steam
- Lovely
- Steamodded `1.0.0~`

## Installation

Extract the mod into its own folder under `%AppData%\Balatro\Mods`. The manifest
must be located at:

`%AppData%\Balatro\Mods\BalatroBalancePatch\balatro_balance_patch.json`

Remove older copies of the same mod before installing version `0.3.17`.

## Compatibility

Other mods that take ownership of the same vanilla Jokers, Vouchers, or Stakes
may conflict depending on load order. Bulky Stakes is optional and can be used
alongside this mod.

## Localization

Includes all 15 locales registered by the base game: English, German, both
Spanish variants, French, Indonesian, Italian, Japanese, Korean, Dutch, Polish,
Brazilian Portuguese, Russian, Simplified Chinese, and Traditional Chinese.
