return {
    descriptions = {
        Joker = {
            j_mystic_summit = {
                text = {
                    "{C:chips}+#1#{} fichas cuando hay",
                    "{C:attention}#2#{} descartes",
                    "restantes",
                },
            },
            j_8_ball = {
                text = {
                    "{C:green}#1# en #2#{} probabilidades por cada",
                    "{C:attention}8{} jugado de generar {C:attention}#3#{} copia",
                    "de la carta {C:tarot}El loco{} cuando anota",
                    "{C:inactive}(Debe haber espacio)",
                },
            },
            j_hiker = {
                text = {
                    "Todas las {C:attention}cartas{} jugadas",
                    "ganan para siempre",
                    "{C:mult}+#1#{} multi cuando anotan",
                },
            },
            j_superposition = {
                text = {
                    "Genera una copia {C:dark_edition}negativa{} de la",
                    "última carta de {C:tarot}tarot{} o {C:planet}planeta{} usada",
                    "si la mano contiene un {C:attention}as{}",
                    "y una {C:attention}escalera{}",
                },
            },
            j_flower_pot = {
                text = {
                    "Las cartas que anotan con {C:attention}2{} palos dan {X:mult,C:white}X#1#{} multi",
                    "Las cartas que anotan con {C:attention}3{} palos dan {X:mult,C:white}X#2#{} multi",
                    "Las cartas que anotan con {C:attention}4{} palos dan {X:mult,C:white}X#3#{} multi",
                },
            },
            j_to_the_moon = {
                text = {
                    "Gana {C:money}$#1#{} extra de {C:attention}interés{}",
                    "por cada {C:money}$#2#{} que tengas",
                    "al final de la ronda",
                },
            },
        },
        Voucher = {
            v_seed_money = {
                text = {
                    "Aumenta el tope de interés",
                    "ganado por ronda a {C:money}$#1#{}",
                },
            },
            v_money_tree = {
                text = {
                    "Aumenta el tope de interés",
                    "ganado por ronda a {C:money}$#1#{}",
                },
            },
        },
        Stake = {
            stake_blue = {
                text = {
                    "La tienda puede tener comodines {C:attention}perecederos{}",
                    "{s:0.8}Se aplica a todos los pozos anteriores",
                },
            },
            stake_orange = {
                text = {
                    "La tienda puede tener comodines {C:attention}de alquiler{}",
                    "{s:0.8}Se aplica a todos los pozos anteriores",
                },
            },
            stake_gold = {
                text = {
                    "Gana {C:money}$2{} de interés por cada {C:money}$10{}",
                    "El interés base tiene un tope de {C:money}$4{} por ronda",
                    "{s:0.8}Se aplica a todos los pozos anteriores",
                },
            },
        },
    },
    misc = {
        dictionary = {
            k_bbp_one_fool = "¡+1 El loco!",
            k_bbp_negative_only = "¡Copia negativa!",
        },
    },
}
