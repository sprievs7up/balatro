return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "Baraja de cartomante",
                text = {
                    "Comienza la partida con cartas",
                    "de {C:tarot}Tarot{} mejoradas, pero no puedes",
                    "obtener cartas de {C:planet}planeta{} ni",
                    "{C:blue,T:blue_seal}sellos azules{}",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "La sacerdotisa",
                text = {
                    "Sube {C:attention}#1#{} niveles la mano de póker",
                    "jugada en la mano anterior",
                },
            },
            c_cartomancer_judgement = {
                name = "El juicio",
                text = {
                    "Genera hasta {C:attention}#1#{} cartas",
                    "de {C:attention}comodín{} al azar",
                    "{C:inactive}(Debe haber espacio)",
                },
            },
        },
    },
}
