return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "Kartomanten-Deck",
                text = {
                    "Beginne den Durchlauf mit verstärkten",
                    "{C:tarot}Tarot{}-Karten, aber {C:planet}Planeten{}-Karten",
                    "und {C:blue,T:blue_seal}Blaue Siegel{} sind nicht erhältlich",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "Die Hohepriesterin",
                text = {
                    "Wertet die Pokerhand aus der vorherigen",
                    "Hand um {C:attention}#1#{} Stufen auf",
                },
            },
            c_cartomancer_judgement = {
                name = "Gericht",
                text = {
                    "Lässt bis zu {C:attention}#1#{} zufällige",
                    "{C:attention}Joker{}-Karten erscheinen",
                    "{C:inactive}(Muss Platz haben)",
                },
            },
        },
    },
}
