return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "占卜師牌組",
                text = {
                    "在強化版的{C:tarot}塔羅牌{}中開始遊戲",
                    "但不再獲得{C:planet}行星牌{}",
                    "以及{C:blue,T:blue_seal}藍色封蠟章{}",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "女祭司",
                text = {
                    "將上一手出牌的",
                    "牌型等級提升{C:attention}#1#級{}",
                },
            },
            c_cartomancer_judgement = {
                name = "審判",
                text = {
                    "產生最多{C:attention}#1#張",
                    "隨機{C:attention}小丑牌{}",
                    "{C:inactive}(必須有空位)",
                },
            },
        },
    },
}
