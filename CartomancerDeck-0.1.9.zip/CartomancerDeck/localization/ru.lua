return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "Колода картоманта",
                text = {
                    "Начинаете партию с усиленными",
                    "картами {C:tarot}Таро{}, но карты {C:planet}планет{}",
                    "и {C:blue,T:blue_seal}Синие печати{}",
                    "нельзя получить",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "Верховная Жрица",
                text = {
                    "Повышает уровень покерной руки из",
                    "предыдущей руки на {C:attention}#1#{} уровня",
                },
            },
            c_cartomancer_judgement = {
                name = "Суд",
                text = {
                    "Создает до {C:attention}#1#{} случайных",
                    "карт {C:attention}джокера{}",
                    "{C:inactive}(должно быть место)",
                },
            },
        },
    },
}
