return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "Jeu du cartomancien",
                text = {
                    "Commencez la partie avec des cartes",
                    "de {C:tarot}Tarot{} améliorées, mais les cartes",
                    "{C:planet}Planète{} et les {C:blue,T:blue_seal}Sceaux bleus{}",
                    "ne peuvent pas être obtenus",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "La Papesse",
                text = {
                    "Améliore de {C:attention}#1#{} niveaux la main de poker",
                    "jouée lors de la main précédente",
                },
            },
            c_cartomancer_judgement = {
                name = "Le Jugement",
                text = {
                    "Crée jusqu'à {C:attention}#1#{} cartes",
                    "{C:attention}Joker{} aléatoires",
                    "{C:inactive}(Selon la place disponible)",
                },
            },
        },
    },
}
