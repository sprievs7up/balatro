return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "占い師デッキ",
                text = {
                    "強化された{C:tarot}タロット{}カードで",
                    "ランをスタートするが、{C:planet}惑星{}カードと",
                    "{C:blue,T:blue_seal}ブルーシール{}は入手できない",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "女教皇",
                text = {
                    "直前のハンドでプレイしたポーカーハンドの",
                    "レベルを {C:attention}#1#{} 上げる",
                },
            },
            c_cartomancer_judgement = {
                name = "審判",
                text = {
                    "ランダムな {C:attention}ジョーカー{} カードを",
                    "最大 {C:attention}#1#{} 枚まで作る",
                    "{C:inactive}（空きが必要）",
                },
            },
        },
    },
}
