return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "Talia kartomanty",
                text = {
                    "Rozpoczynasz podejście ze",
                    "wzmocnionymi kartami {C:tarot}Tarota{}, ale",
                    "nie możesz otrzymywać kart {C:planet}Planet{}",
                    "ani {C:blue,T:blue_seal}Niebieskich Pieczęci{}",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "Arcykapłanka",
                text = {
                    "Zwiększa o {C:attention}#1#{} poziomy układ pokerowy",
                    "zagrany w poprzednim rozdaniu",
                },
            },
            c_cartomancer_judgement = {
                name = "Wyrok",
                text = {
                    "Otrzymujesz maks. {C:attention}#1#{}",
                    "losowych {C:attention}jokerów{}",
                    "{C:inactive}(wymaga miejsca)",
                },
            },
        },
    },
}
