return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "Cartomancer Deck",
                text = {
                    "Start a run with enhanced {C:tarot}Tarot cards{}",
                    "but {C:planet}Planet cards{} and",
                    "{C:blue,T:blue_seal}Blue Seals{} cannot be obtained",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "The High Priestess",
                text = {
                    "Upgrade the poker hand played",
                    "in the previous hand by {C:attention}#1#{} levels",
                },
            },
            c_cartomancer_judgement = {
                name = "Judgement",
                text = {
                    "Creates up to {C:attention}#1#{} random",
                    "{C:attention}Joker{} cards",
                    "{C:inactive}(Must have room)",
                },
            },
        },
    },
}
