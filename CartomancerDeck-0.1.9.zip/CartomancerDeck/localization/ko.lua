return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "점술가 덱",
                text = {
                    "강화된 {C:tarot}타로{} 카드로 런을 시작하지만",
                    "{C:planet}행성{} 카드와 {C:blue,T:blue_seal}블루 봉인{}은",
                    "획득할 수 없습니다",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "고위 여사제",
                text = {
                    "이전 핸드에서 플레이한 포커 핸드의",
                    "레벨을 {C:attention}#1#{} 올립니다",
                },
            },
            c_cartomancer_judgement = {
                name = "심판",
                text = {
                    "무작위 {C:attention}조커{} 카드를",
                    "최대 {C:attention}#1#{}장 생성합니다",
                    "{C:inactive}(공간이 있어야 합니다)",
                },
            },
        },
    },
}
