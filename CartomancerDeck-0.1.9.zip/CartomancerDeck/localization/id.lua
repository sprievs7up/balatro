return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "Deck Cartomancer",
                text = {
                    "Mulai giliran dengan kartu",
                    "{C:tarot}Tarot{} yang ditingkatkan, tetapi",
                    "kartu {C:planet}Planet{} dan {C:blue,T:blue_seal}Blue Seal{}",
                    "tidak dapat diperoleh",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "The High Priestess",
                text = {
                    "Tingkatkan poker hand dari hand",
                    "sebelumnya sebanyak {C:attention}#1#{} level",
                },
            },
            c_cartomancer_judgement = {
                name = "Judgement",
                text = {
                    "Memunculkan hingga {C:attention}#1#{} kartu",
                    "{C:attention}Joker{} secara acak",
                    "{C:inactive}(Harus memiliki tempat)",
                },
            },
        },
    },
}
