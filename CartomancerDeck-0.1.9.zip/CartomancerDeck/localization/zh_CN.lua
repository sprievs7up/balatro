return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "占卜师牌组",
                text = {
                    "在增强版的{C:tarot}塔罗牌{}中开始游戏",
                    "但不再获取{C:planet}星球牌{}",
                    "以及{C:blue,T:blue_seal}蓝色蜡封{}",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "女祭司",
                text = {
                    "将上一手出牌的",
                    "牌型等级提升{C:attention}#1#级{}",
                },
            },
            c_cartomancer_judgement = {
                name = "审判",
                text = {
                    "生成最多{C:attention}#1#张",
                    "随机{C:attention}小丑牌{}",
                    "{C:inactive}（必须有空位）",
                },
            },
        },
    },
}
