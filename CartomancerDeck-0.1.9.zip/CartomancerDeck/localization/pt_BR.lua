return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "Baralho do Cartomante",
                text = {
                    "Comece a tentativa com cartas",
                    "de {C:tarot}Tarô{} aprimoradas, mas cartas",
                    "de {C:planet}Planeta{} e {C:blue,T:blue_seal}Selos Azuis{}",
                    "não podem ser obtidos",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "A Sacerdotisa",
                text = {
                    "Aumenta em {C:attention}#1#{} níveis a mão de pôquer",
                    "jogada na mão anterior",
                },
            },
            c_cartomancer_judgement = {
                name = "Julgamento",
                text = {
                    "Cria até {C:attention}#1#{} cartas",
                    "{C:attention}Curinga{} aleatórias",
                    "{C:inactive}(Deve ter espaço)",
                },
            },
        },
    },
}
