return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "Waarzeggerskaartspel",
                text = {
                    "Begin het spel met versterkte",
                    "{C:tarot}Tarot{}-kaarten, maar",
                    "{C:planet}planeet{}-kaarten en {C:blue,T:blue_seal}blauwe zegels{}",
                    "kunnen niet worden verkregen",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "De hogepriesteres",
                text = {
                    "Verhoog het niveau van de pokerhand uit",
                    "de vorige hand met {C:attention}#1#{} niveaus",
                },
            },
            c_cartomancer_judgement = {
                name = "Het oordeel",
                text = {
                    "Maakt tot {C:attention}#1#{} willekeurige",
                    "{C:attention}Joker{}-kaarten verschijnen",
                    "{C:inactive}(Moet ruimte voor zijn)",
                },
            },
        },
    },
}
