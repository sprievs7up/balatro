return {
    descriptions = {
        Back = {
            b_cartomancer_deck = {
                name = "Mazzo del cartomante",
                text = {
                    "Inizia la sessione con carte",
                    "{C:tarot}Tarocco{} potenziate, ma non puoi",
                    "ottenere carte {C:planet}Pianeta{} né",
                    "{C:blue,T:blue_seal}Sigilli blu{}",
                },
            },
        },
        Tarot = {
            c_cartomancer_high_priestess = {
                name = "La papessa",
                text = {
                    "Aumenta di {C:attention}#1#{} livelli la mano di poker",
                    "giocata nella mano precedente",
                },
            },
            c_cartomancer_judgement = {
                name = "Il giudizio",
                text = {
                    "Crea fino a {C:attention}#1#{}",
                    "{C:attention}Jolly{} casuali",
                    "{C:inactive}(Serve spazio)",
                },
            },
        },
    },
}
